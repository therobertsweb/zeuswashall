from __future__ import annotations

import math
import os
import re
import sqlite3
from datetime import datetime
from functools import wraps
from pathlib import Path
from uuid import uuid4

from flask import Flask, flash, g, jsonify, redirect, render_template, request, send_from_directory, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "quotes.db"
BLOG_UPLOAD_DIR = BASE_DIR / "assets" / "uploads" / "blogs"
ALLOWED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".gif"}

app = Flask(__name__, static_folder="assets", static_url_path="/assets")
app.config["SECRET_KEY"] = "zeuswashall-quote-secret"
app.config["OWNER_USERNAME"] = os.getenv("OWNER_USERNAME", "admin")
app.config["OWNER_PASSWORD"] = os.getenv("OWNER_PASSWORD", "admin123")
app.config["OWNER_EMAIL"] = os.getenv("OWNER_EMAIL", "owner@zeuswashall.com")
app.config["REVIEW_DEFAULT_STATUS"] = os.getenv("REVIEW_DEFAULT_STATUS", "Approved")

SERVICE_RATES = {
    "commercial_cleaning": 62.0,
    "auto_detailing": 50.0,
    "residential_deep_clean": 56.0,
    "regular_cleaning": 48.0,
    "driveway_cleaning": 45.0,
    "dumpster_bin_cleaning": 39.0,
    "window_cleaning": 44.0,
}

SERVICE_LABELS = {
    "commercial_cleaning": "Commercial Cleaning",
    "auto_detailing": "Auto Detailing",
    "residential_deep_clean": "Residential Deep Clean",
    "regular_cleaning": "Regular Cleaning",
    "driveway_cleaning": "Driveway Cleaning",
    "dumpster_bin_cleaning": "Dumpster Bin Cleaning",
    "window_cleaning": "Window Cleaning",
}

FREQUENCY_MULTIPLIER = {
    "one_time": 1.0,
    "weekly": 0.92,
    "biweekly": 0.95,
    "monthly": 0.98,
}

FREQUENCY_LABELS = {
    "one_time": "One-time",
    "weekly": "Weekly",
    "biweekly": "Biweekly",
    "monthly": "Monthly",
}

STATUS_OPTIONS = ["New Request", "Contacted", "Quoted", "Approved", "Rejected"]


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(error: Exception | None) -> None:
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db() -> None:
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS quotes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            quote_number TEXT NOT NULL UNIQUE,
            created_at TEXT NOT NULL,
            client_name TEXT NOT NULL,
            email TEXT,
            phone TEXT,
            service_type TEXT NOT NULL,
            frequency TEXT NOT NULL,
            property_size TEXT,
            estimated_hours REAL NOT NULL,
            hourly_rate REAL NOT NULL,
            materials_fee REAL NOT NULL,
            tax_rate REAL NOT NULL,
            subtotal REAL NOT NULL,
            tax_amount REAL NOT NULL,
            total REAL NOT NULL,
            notes TEXT,
            status TEXT NOT NULL DEFAULT 'New Request'
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS blog_posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            slug TEXT NOT NULL UNIQUE,
            excerpt TEXT,
            image_url TEXT,
            content TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Draft',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_name TEXT NOT NULL,
            rating INTEGER NOT NULL,
            message TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Pending',
            created_at TEXT NOT NULL
        )
        """
    )
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS contact_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            phone TEXT,
            email TEXT,
            service TEXT,
            preferred_date TEXT,
            location TEXT,
            message TEXT,
            status TEXT NOT NULL DEFAULT 'New',
            created_at TEXT NOT NULL
        )
        """
    )

    db.execute(
        """
        CREATE TABLE IF NOT EXISTS owner_settings (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            username TEXT NOT NULL,
            email TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )

    owner_row = db.execute("SELECT id FROM owner_settings WHERE id = 1").fetchone()
    if owner_row is None:
        db.execute(
            """
            INSERT INTO owner_settings (id, username, email, password_hash, updated_at)
            VALUES (1, ?, ?, ?, ?)
            """,
            (
                app.config["OWNER_USERNAME"],
                app.config["OWNER_EMAIL"],
                generate_password_hash(app.config["OWNER_PASSWORD"], method="pbkdf2:sha256"),
                datetime.now().isoformat(timespec="seconds"),
            ),
        )

    db.commit()
    db.close()


def calculate_quote(service_type: str, frequency: str, hours: float, materials_fee: float, tax_rate: float) -> dict:
    hourly_rate = SERVICE_RATES.get(service_type, 45.0)
    frequency_factor = FREQUENCY_MULTIPLIER.get(frequency, 1.0)
    subtotal = (hours * hourly_rate * frequency_factor) + materials_fee
    tax_amount = subtotal * (tax_rate / 100)
    total = subtotal + tax_amount

    return {
        "hourly_rate": round(hourly_rate, 2),
        "subtotal": round(subtotal, 2),
        "tax_amount": round(tax_amount, 2),
        "total": round(total, 2),
    }


def next_quote_number() -> str:
    now = datetime.now()
    db = get_db()
    prefix = f"ZEUS-{now.strftime('%Y%m')}-"
    row = db.execute(
        "SELECT quote_number FROM quotes WHERE quote_number LIKE ? ORDER BY id DESC LIMIT 1",
        (f"{prefix}%",),
    ).fetchone()

    if row:
        current = int(row["quote_number"].split("-")[-1])
        sequence = current + 1
    else:
        sequence = 1

    return f"{prefix}{sequence:03d}"


def slugify(text: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9\s-]", "", text).strip().lower()
    value = re.sub(r"[\s_-]+", "-", value)
    return value or "post"


def build_unique_slug(title: str, current_id: int | None = None) -> str:
    base = slugify(title)
    slug = base
    suffix = 2
    db = get_db()

    while True:
        if current_id is None:
            row = db.execute("SELECT id FROM blog_posts WHERE slug = ?", (slug,)).fetchone()
        else:
            row = db.execute(
                "SELECT id FROM blog_posts WHERE slug = ? AND id != ?",
                (slug, current_id),
            ).fetchone()

        if row is None:
            return slug

        slug = f"{base}-{suffix}"
        suffix += 1


def strip_html(text: str) -> str:
    return re.sub(r"<[^>]+>", "", text)


def owner_required(view_func):
    @wraps(view_func)
    def wrapped(*args, **kwargs):
        if not session.get("owner_logged_in"):
            flash("Owner login required.", "warning")
            return redirect(url_for("owner_login", next=request.path))
        return view_func(*args, **kwargs)

    return wrapped


def is_local_blog_upload(url: str | None) -> bool:
    return bool(url and url.startswith("/assets/uploads/blogs/"))


def remove_local_blog_image(url: str | None) -> None:
    if not is_local_blog_upload(url):
        return

    relative = url.replace("/assets/", "", 1)
    target = BASE_DIR / "assets" / relative
    if target.exists():
        target.unlink()


def save_blog_image(file_storage):
    if file_storage is None or not file_storage.filename:
        return None, None

    filename = secure_filename(file_storage.filename)
    ext = Path(filename).suffix.lower()

    if ext not in ALLOWED_IMAGE_EXTENSIONS:
        return None, "Invalid image type. Use jpg, jpeg, png, webp or gif."

    BLOG_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    stored_name = f"{datetime.now().strftime('%Y%m%d%H%M%S')}-{uuid4().hex[:8]}{ext}"
    file_storage.save(BLOG_UPLOAD_DIR / stored_name)
    return f"/assets/uploads/blogs/{stored_name}", None


def parse_page_arg(default: int = 1) -> int:
    try:
        page = int(request.args.get("page", str(default)))
    except ValueError:
        page = default
    return page if page > 0 else default


def get_owner_settings_row() -> sqlite3.Row:
    db = get_db()
    row = db.execute(
        "SELECT id, username, email, password_hash, updated_at FROM owner_settings WHERE id = 1"
    ).fetchone()

    if row is not None:
        return row

    db.execute(
        """
        INSERT INTO owner_settings (id, username, email, password_hash, updated_at)
        VALUES (1, ?, ?, ?, ?)
        """,
        (
            app.config["OWNER_USERNAME"],
            app.config["OWNER_EMAIL"],
            generate_password_hash(app.config["OWNER_PASSWORD"], method="pbkdf2:sha256"),
            datetime.now().isoformat(timespec="seconds"),
        ),
    )
    db.commit()
    return db.execute(
        "SELECT id, username, email, password_hash, updated_at FROM owner_settings WHERE id = 1"
    ).fetchone()


def parse_quote_form(form: dict[str, str]) -> tuple[dict, str | None]:
    client_name = form.get("client_name", "").strip()
    email = form.get("email", "").strip()
    phone = form.get("phone", "").strip()
    service_type = form.get("service_type", "").strip()
    frequency = form.get("frequency", "one_time").strip()
    property_size = form.get("property_size", "").strip()
    notes = form.get("notes", "").strip()

    try:
        estimated_hours = float(form.get("estimated_hours", "0"))
        materials_fee = float(form.get("materials_fee", "0"))
        tax_rate = float(form.get("tax_rate", "8.375"))
    except ValueError:
        return {}, "Please enter valid numeric values for hours, materials and tax."

    if not client_name or service_type not in SERVICE_LABELS:
        return {}, "Client name and service type are required."

    if estimated_hours <= 0:
        return {}, "Estimated hours must be greater than zero."

    if frequency not in FREQUENCY_LABELS:
        return {}, "Frequency is invalid."

    payload = {
        "client_name": client_name,
        "email": email,
        "phone": phone,
        "service_type": service_type,
        "frequency": frequency,
        "property_size": property_size,
        "estimated_hours": estimated_hours,
        "materials_fee": materials_fee,
        "tax_rate": tax_rate,
        "notes": notes,
    }
    return payload, None


def parse_service_request_form(form: dict[str, str]) -> tuple[dict, str | None]:
    client_name = form.get("client_name", "").strip()
    email = form.get("email", "").strip()
    phone = form.get("phone", "").strip()
    service_type = form.get("service_type", "").strip()
    frequency = form.get("frequency", "one_time").strip()
    property_size = form.get("property_size", "").strip()
    notes = form.get("notes", "").strip()

    if not client_name or service_type not in SERVICE_LABELS:
        return {}, "Client name and service type are required."

    if frequency not in FREQUENCY_LABELS:
        return {}, "Frequency is invalid."

    payload = {
        "client_name": client_name,
        "email": email,
        "phone": phone,
        "service_type": service_type,
        "frequency": frequency,
        "property_size": property_size,
        "notes": notes,
    }
    return payload, None


def quote_not_found_redirect():
    flash("Quote not found.", "danger")
    return redirect(url_for("owner_dashboard"))


@app.route("/")
def home():
    return send_from_directory(BASE_DIR, "index.html")


@app.route("/software", methods=["GET", "POST"])
def new_quote():
    if request.method == "POST":
        payload, error = parse_service_request_form(request.form)
        if error:
            flash(error, "danger")
            return redirect(url_for("new_quote"))

        hourly_rate = SERVICE_RATES.get(payload["service_type"], 45.0)
        quote_number = next_quote_number()

        db = get_db()
        db.execute(
            """
            INSERT INTO quotes (
                quote_number, created_at, client_name, email, phone, service_type, frequency,
                property_size, estimated_hours, hourly_rate, materials_fee, tax_rate,
                subtotal, tax_amount, total, notes, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                quote_number,
                datetime.now().isoformat(timespec="seconds"),
                payload["client_name"],
                payload["email"],
                payload["phone"],
                payload["service_type"],
                payload["frequency"],
                payload["property_size"],
                0,
                hourly_rate,
                0,
                0,
                0,
                0,
                0,
                payload["notes"],
                "New Request",
            ),
        )
        db.commit()

        quote_id = db.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
        flash("Service request sent successfully. We will contact you soon.", "success")
        return redirect(url_for("quote_detail", quote_id=quote_id))

    return render_template(
        "new_quote.html",
        page_mode="client",
        service_labels=SERVICE_LABELS,
        frequency_labels=FREQUENCY_LABELS,
        service_rates=SERVICE_RATES,
        status_options=STATUS_OPTIONS,
    )


@app.route("/dashboard")
@owner_required
def owner_dashboard():
    db = get_db()
    status_filter = request.args.get("status", "all").strip()
    search = request.args.get("q", "").strip()

    where = []
    params: list[str] = []

    if status_filter != "all" and status_filter in STATUS_OPTIONS:
        where.append("status = ?")
        params.append(status_filter)

    if search:
        where.append("(client_name LIKE ? OR email LIKE ? OR quote_number LIKE ?)")
        wildcard = f"%{search}%"
        params.extend([wildcard, wildcard, wildcard])

    where_clause = f"WHERE {' AND '.join(where)}" if where else ""

    rows = db.execute(
        f"""
        SELECT id, quote_number, created_at, client_name, service_type, frequency, total, status
        FROM quotes
        {where_clause}
        ORDER BY id DESC
        """,
        tuple(params),
    ).fetchall()

    total_quotes = db.execute("SELECT COUNT(*) AS total FROM quotes").fetchone()["total"]
    approved_quotes = db.execute(
        "SELECT COUNT(*) AS total FROM quotes WHERE status = 'Approved'"
    ).fetchone()["total"]
    open_quotes = db.execute(
        "SELECT COUNT(*) AS total FROM quotes WHERE status IN ('New Request', 'Contacted', 'Quoted', 'Draft', 'Sent')"
    ).fetchone()["total"]
    approved_revenue = db.execute(
        "SELECT COALESCE(SUM(total), 0) AS amount FROM quotes WHERE status = 'Approved'"
    ).fetchone()["amount"]
    pending_reviews = db.execute(
        "SELECT COUNT(*) AS total FROM reviews WHERE status = 'Pending'"
    ).fetchone()["total"]
    published_blogs = db.execute(
        "SELECT COUNT(*) AS total FROM blog_posts WHERE status = 'Published'"
    ).fetchone()["total"]
    pending_contacts = db.execute(
        "SELECT COUNT(*) AS total FROM contact_requests WHERE status = 'New'"
    ).fetchone()["total"]

    return render_template(
        "dashboard.html",
        quotes=rows,
        service_labels=SERVICE_LABELS,
        frequency_labels=FREQUENCY_LABELS,
        status_options=STATUS_OPTIONS,
        status_filter=status_filter,
        search=search,
        total_quotes=total_quotes,
        approved_quotes=approved_quotes,
        open_quotes=open_quotes,
        approved_revenue=approved_revenue,
        pending_reviews=pending_reviews,
        published_blogs=published_blogs,
        pending_contacts=pending_contacts,
    )


@app.route("/dashboard/contacts")
@owner_required
def dashboard_contacts():
    db = get_db()
    page = parse_page_arg()
    page_size = 10
    offset = (page - 1) * page_size
    total = db.execute("SELECT COUNT(*) AS total FROM contact_requests").fetchone()["total"]
    total_pages = max(1, math.ceil(total / page_size)) if total else 1
    if page > total_pages:
        page = total_pages
        offset = (page - 1) * page_size

    rows = db.execute(
        """
        SELECT id, full_name, phone, email, service, preferred_date, location, message, status, created_at
        FROM contact_requests
        ORDER BY id DESC
        LIMIT ? OFFSET ?
        """,
        (page_size, offset),
    ).fetchall()
    return render_template("dashboard_contacts.html", contacts=rows, page=page, total_pages=total_pages)


@app.route("/dashboard/contacts/<int:contact_id>/status", methods=["POST"])
@owner_required
def dashboard_contact_status(contact_id: int):
    status = request.form.get("status", "New")
    if status not in {"New", "Contacted", "Closed"}:
        flash("Invalid contact status.", "danger")
        return redirect(url_for("dashboard_contacts"))

    db = get_db()
    db.execute("UPDATE contact_requests SET status = ? WHERE id = ?", (status, contact_id))
    db.commit()
    flash("Contact request updated.", "success")
    return redirect(url_for("dashboard_contacts"))


@app.route("/dashboard/quote/new", methods=["GET", "POST"])
@owner_required
def owner_create_quote():
    if request.method == "POST":
        payload, error = parse_quote_form(request.form)
        if error:
            flash(error, "danger")
            return redirect(url_for("owner_create_quote"))

        status = request.form.get("status", "New Request")
        if status not in STATUS_OPTIONS:
            status = "New Request"

        calc = calculate_quote(
            payload["service_type"],
            payload["frequency"],
            payload["estimated_hours"],
            payload["materials_fee"],
            payload["tax_rate"],
        )
        quote_number = next_quote_number()

        db = get_db()
        db.execute(
            """
            INSERT INTO quotes (
                quote_number, created_at, client_name, email, phone, service_type, frequency,
                property_size, estimated_hours, hourly_rate, materials_fee, tax_rate,
                subtotal, tax_amount, total, notes, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                quote_number,
                datetime.now().isoformat(timespec="seconds"),
                payload["client_name"],
                payload["email"],
                payload["phone"],
                payload["service_type"],
                payload["frequency"],
                payload["property_size"],
                payload["estimated_hours"],
                calc["hourly_rate"],
                payload["materials_fee"],
                payload["tax_rate"],
                calc["subtotal"],
                calc["tax_amount"],
                calc["total"],
                payload["notes"],
                status,
            ),
        )
        db.commit()
        flash(f"Quote {quote_number} created in dashboard.", "success")
        return redirect(url_for("owner_dashboard"))

    return render_template(
        "new_quote.html",
        page_mode="owner",
        service_labels=SERVICE_LABELS,
        frequency_labels=FREQUENCY_LABELS,
        service_rates=SERVICE_RATES,
        status_options=STATUS_OPTIONS,
    )


@app.route("/quotes")
def quote_list():
    return redirect(url_for("owner_dashboard"))


@app.route("/dashboard/quote/<int:quote_id>")
@owner_required
def owner_quote_detail(quote_id: int):
    db = get_db()
    quote = db.execute("SELECT * FROM quotes WHERE id = ?", (quote_id,)).fetchone()
    if quote is None:
        return quote_not_found_redirect()

    return render_template(
        "quote_detail.html",
        page_mode="owner",
        quote=quote,
        service_labels=SERVICE_LABELS,
        frequency_labels=FREQUENCY_LABELS,
        status_options=STATUS_OPTIONS,
    )


@app.route("/quote/<int:quote_id>")
def quote_detail(quote_id: int):
    db = get_db()
    quote = db.execute("SELECT * FROM quotes WHERE id = ?", (quote_id,)).fetchone()

    if quote is None:
        return quote_not_found_redirect()

    return render_template(
        "quote_detail.html",
        page_mode="client",
        quote=quote,
        service_labels=SERVICE_LABELS,
        frequency_labels=FREQUENCY_LABELS,
        status_options=STATUS_OPTIONS,
    )


@app.route("/dashboard/quote/<int:quote_id>/edit", methods=["GET", "POST"])
@owner_required
def owner_edit_quote(quote_id: int):
    db = get_db()
    quote = db.execute("SELECT * FROM quotes WHERE id = ?", (quote_id,)).fetchone()
    if quote is None:
        return quote_not_found_redirect()

    if request.method == "POST":
        payload, error = parse_quote_form(request.form)
        if error:
            flash(error, "danger")
            return redirect(url_for("owner_edit_quote", quote_id=quote_id))

        status = request.form.get("status", "New Request")
        if status not in STATUS_OPTIONS:
            status = "New Request"

        calc = calculate_quote(
            payload["service_type"],
            payload["frequency"],
            payload["estimated_hours"],
            payload["materials_fee"],
            payload["tax_rate"],
        )

        db.execute(
            """
            UPDATE quotes
            SET client_name = ?, email = ?, phone = ?, service_type = ?, frequency = ?,
                property_size = ?, estimated_hours = ?, hourly_rate = ?, materials_fee = ?,
                tax_rate = ?, subtotal = ?, tax_amount = ?, total = ?, notes = ?, status = ?
            WHERE id = ?
            """,
            (
                payload["client_name"],
                payload["email"],
                payload["phone"],
                payload["service_type"],
                payload["frequency"],
                payload["property_size"],
                payload["estimated_hours"],
                calc["hourly_rate"],
                payload["materials_fee"],
                payload["tax_rate"],
                calc["subtotal"],
                calc["tax_amount"],
                calc["total"],
                payload["notes"],
                status,
                quote_id,
            ),
        )
        db.commit()
        flash("Quote updated successfully.", "success")
        return redirect(url_for("owner_quote_detail", quote_id=quote_id))

    return render_template(
        "quote_edit.html",
        quote=quote,
        service_labels=SERVICE_LABELS,
        frequency_labels=FREQUENCY_LABELS,
        status_options=STATUS_OPTIONS,
    )


@app.route("/quote/<int:quote_id>/status", methods=["POST"])
@owner_required
def update_status(quote_id: int):
    status = request.form.get("status", "New Request")
    allowed = set(STATUS_OPTIONS)

    if status not in allowed:
        flash("Invalid status.", "danger")
        return redirect(url_for("quote_detail", quote_id=quote_id))

    db = get_db()
    db.execute("UPDATE quotes SET status = ? WHERE id = ?", (status, quote_id))
    db.commit()

    flash("Quote status updated.", "success")
    if request.form.get("source") == "owner":
        return redirect(url_for("owner_quote_detail", quote_id=quote_id))
    return redirect(url_for("quote_detail", quote_id=quote_id))


@app.route("/dashboard/quote/<int:quote_id>/delete", methods=["POST"])
@owner_required
def owner_delete_quote(quote_id: int):
    db = get_db()
    existing = db.execute("SELECT quote_number FROM quotes WHERE id = ?", (quote_id,)).fetchone()
    if existing is None:
        return quote_not_found_redirect()

    db.execute("DELETE FROM quotes WHERE id = ?", (quote_id,))
    db.commit()
    flash(f"Quote {existing['quote_number']} deleted.", "success")
    return redirect(url_for("owner_dashboard"))


@app.route("/dashboard/blogs")
@owner_required
def dashboard_blogs():
    db = get_db()
    page = parse_page_arg()
    page_size = 8
    offset = (page - 1) * page_size
    total = db.execute("SELECT COUNT(*) AS total FROM blog_posts").fetchone()["total"]
    total_pages = max(1, math.ceil(total / page_size)) if total else 1
    if page > total_pages:
        page = total_pages
        offset = (page - 1) * page_size

    rows = db.execute(
        """
        SELECT id, title, slug, status, created_at, updated_at
        FROM blog_posts
        ORDER BY id DESC
        LIMIT ? OFFSET ?
        """
        ,
        (page_size, offset),
    ).fetchall()
    return render_template("dashboard_blogs.html", blogs=rows, page=page, total_pages=total_pages)


@app.route("/dashboard/blogs/new", methods=["GET", "POST"])
@owner_required
def dashboard_blog_new():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        excerpt = request.form.get("excerpt", "").strip()
        image_url = request.form.get("image_url", "").strip()
        content = request.form.get("content", "").strip()
        status = request.form.get("status", "Draft").strip()

        if not title or not content:
            flash("Title and content are required.", "danger")
            return redirect(url_for("dashboard_blog_new"))

        if status not in {"Draft", "Published"}:
            status = "Draft"

        if not excerpt:
            excerpt = strip_html(content)[:160]

        upload_url, upload_error = save_blog_image(request.files.get("image_file"))
        if upload_error:
            flash(upload_error, "danger")
            return redirect(url_for("dashboard_blog_new"))
        if upload_url:
            image_url = upload_url

        slug = build_unique_slug(title)
        now = datetime.now().isoformat(timespec="seconds")

        db = get_db()
        db.execute(
            """
            INSERT INTO blog_posts (title, slug, excerpt, image_url, content, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (title, slug, excerpt, image_url, content, status, now, now),
        )
        db.commit()
        flash("Blog post created.", "success")
        return redirect(url_for("dashboard_blogs"))

    return render_template("blog_form.html", blog=None)


@app.route("/dashboard/blogs/<int:blog_id>/edit", methods=["GET", "POST"])
@owner_required
def dashboard_blog_edit(blog_id: int):
    db = get_db()
    blog = db.execute("SELECT * FROM blog_posts WHERE id = ?", (blog_id,)).fetchone()
    if blog is None:
        flash("Blog post not found.", "danger")
        return redirect(url_for("dashboard_blogs"))

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        excerpt = request.form.get("excerpt", "").strip()
        image_url = request.form.get("image_url", "").strip()
        content = request.form.get("content", "").strip()
        status = request.form.get("status", "Draft").strip()

        if not title or not content:
            flash("Title and content are required.", "danger")
            return redirect(url_for("dashboard_blog_edit", blog_id=blog_id))

        if status not in {"Draft", "Published"}:
            status = "Draft"

        if not excerpt:
            excerpt = strip_html(content)[:160]

        if request.form.get("remove_image") == "1":
            remove_local_blog_image(blog["image_url"])
            image_url = ""

        upload_url, upload_error = save_blog_image(request.files.get("image_file"))
        if upload_error:
            flash(upload_error, "danger")
            return redirect(url_for("dashboard_blog_edit", blog_id=blog_id))
        if upload_url:
            remove_local_blog_image(blog["image_url"])
            image_url = upload_url

        slug = build_unique_slug(title, current_id=blog_id)

        db.execute(
            """
            UPDATE blog_posts
            SET title = ?, slug = ?, excerpt = ?, image_url = ?, content = ?, status = ?, updated_at = ?
            WHERE id = ?
            """,
            (
                title,
                slug,
                excerpt,
                image_url,
                content,
                status,
                datetime.now().isoformat(timespec="seconds"),
                blog_id,
            ),
        )
        db.commit()
        flash("Blog post updated.", "success")
        return redirect(url_for("dashboard_blogs"))

    return render_template("blog_form.html", blog=blog)


@app.route("/dashboard/blogs/<int:blog_id>/delete", methods=["POST"])
@owner_required
def dashboard_blog_delete(blog_id: int):
    db = get_db()
    row = db.execute("SELECT title, image_url FROM blog_posts WHERE id = ?", (blog_id,)).fetchone()
    if row is None:
        flash("Blog post not found.", "danger")
        return redirect(url_for("dashboard_blogs"))

    remove_local_blog_image(row["image_url"])
    db.execute("DELETE FROM blog_posts WHERE id = ?", (blog_id,))
    db.commit()
    flash(f"Deleted blog: {row['title']}", "success")
    return redirect(url_for("dashboard_blogs"))


@app.route("/dashboard/reviews")
@owner_required
def dashboard_reviews():
    db = get_db()
    page = parse_page_arg()
    page_size = 10
    offset = (page - 1) * page_size
    total = db.execute("SELECT COUNT(*) AS total FROM reviews").fetchone()["total"]
    total_pages = max(1, math.ceil(total / page_size)) if total else 1
    if page > total_pages:
        page = total_pages
        offset = (page - 1) * page_size

    rows = db.execute(
        """
        SELECT id, client_name, rating, message, status, created_at
        FROM reviews
        ORDER BY id DESC
        LIMIT ? OFFSET ?
        """
        ,
        (page_size, offset),
    ).fetchall()
    return render_template("dashboard_reviews.html", reviews=rows, page=page, total_pages=total_pages)


@app.route("/dashboard/reviews/<int:review_id>/status", methods=["POST"])
@owner_required
def dashboard_review_status(review_id: int):
    status = request.form.get("status", "Pending")
    if status not in {"Pending", "Approved", "Rejected"}:
        flash("Invalid review status.", "danger")
        return redirect(url_for("dashboard_reviews"))

    db = get_db()
    db.execute("UPDATE reviews SET status = ? WHERE id = ?", (status, review_id))
    db.commit()
    flash("Review status updated.", "success")
    return redirect(url_for("dashboard_reviews"))


@app.route("/dashboard/reviews/<int:review_id>/delete", methods=["POST"])
@owner_required
def dashboard_review_delete(review_id: int):
    db = get_db()
    row = db.execute("SELECT client_name FROM reviews WHERE id = ?", (review_id,)).fetchone()
    if row is None:
        flash("Review not found.", "danger")
        return redirect(url_for("dashboard_reviews"))

    db.execute("DELETE FROM reviews WHERE id = ?", (review_id,))
    db.commit()
    flash(f"Deleted review from {row['client_name']}.", "success")
    return redirect(url_for("dashboard_reviews"))


@app.route("/api/blogs")
def api_blogs():
    db = get_db()
    rows = db.execute(
        """
        SELECT title, slug, excerpt, image_url, created_at
        FROM blog_posts
        WHERE status = 'Published'
        ORDER BY id DESC
        LIMIT 6
        """
    ).fetchall()
    return jsonify(
        [
            {
                "title": row["title"],
                "slug": row["slug"],
                "excerpt": row["excerpt"] or "",
                "image_url": row["image_url"] or "",
                "created_at": row["created_at"],
            }
            for row in rows
        ]
    )


@app.route("/blog/<slug>")
def blog_detail(slug: str):
    db = get_db()
    blog = db.execute(
        "SELECT * FROM blog_posts WHERE slug = ? AND status = 'Published'",
        (slug,),
    ).fetchone()
    if blog is None:
        flash("Blog post not found.", "danger")
        return redirect(url_for("home"))
    return render_template("blog_detail.html", blog=blog)


@app.route("/owner/login", methods=["GET", "POST"])
def owner_login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        next_path = request.form.get("next", "").strip()
        owner = get_owner_settings_row()

        if (
            username == owner["username"]
            and check_password_hash(owner["password_hash"], password)
        ):
            session["owner_logged_in"] = True
            session["owner_username"] = username
            flash("Logged in successfully.", "success")
            if next_path.startswith("/"):
                return redirect(next_path)
            return redirect(url_for("owner_dashboard"))

        flash("Invalid credentials.", "danger")

    next_path = request.args.get("next", "")
    return render_template("owner_login.html", next_path=next_path)


@app.route("/owner/logout", methods=["POST"])
def owner_logout():
    session.pop("owner_logged_in", None)
    session.pop("owner_username", None)
    flash("Logged out.", "success")
    return redirect(url_for("owner_login"))


@app.route("/dashboard/settings", methods=["GET", "POST"])
@owner_required
def dashboard_settings():
    owner = get_owner_settings_row()

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        current_password = request.form.get("current_password", "")
        new_password = request.form.get("new_password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not username or not email:
            flash("Username and email are required.", "danger")
            return redirect(url_for("dashboard_settings"))

        if not check_password_hash(owner["password_hash"], current_password):
            flash("Current password is incorrect.", "danger")
            return redirect(url_for("dashboard_settings"))

        password_hash = owner["password_hash"]
        if new_password or confirm_password:
            if len(new_password) < 8:
                flash("New password must be at least 8 characters.", "danger")
                return redirect(url_for("dashboard_settings"))
            if new_password != confirm_password:
                flash("New password and confirmation do not match.", "danger")
                return redirect(url_for("dashboard_settings"))
            password_hash = generate_password_hash(new_password, method="pbkdf2:sha256")

        db = get_db()
        db.execute(
            """
            UPDATE owner_settings
            SET username = ?, email = ?, password_hash = ?, updated_at = ?
            WHERE id = 1
            """,
            (
                username,
                email,
                password_hash,
                datetime.now().isoformat(timespec="seconds"),
            ),
        )
        db.commit()

        session["owner_username"] = username
        flash("Owner settings updated.", "success")
        return redirect(url_for("dashboard_settings"))

    return render_template("dashboard_settings.html", owner=owner)


@app.route("/api/reviews", methods=["GET", "POST"])
def api_reviews():
    db = get_db()
    if request.method == "POST":
        payload = request.get_json(silent=True) or {}
        client_name = str(payload.get("client_name", "")).strip()
        message = str(payload.get("message", "")).strip()

        try:
            rating = int(payload.get("rating", 0))
        except (TypeError, ValueError):
            rating = 0

        if not client_name or not message or rating < 1 or rating > 5:
            return jsonify({"ok": False, "error": "Invalid review payload."}), 400

        status = app.config.get("REVIEW_DEFAULT_STATUS", "Approved")
        if status not in {"Pending", "Approved", "Rejected"}:
            status = "Approved"

        db.execute(
            """
            INSERT INTO reviews (client_name, rating, message, status, created_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (client_name, rating, message, status, datetime.now().isoformat(timespec="seconds")),
        )
        db.commit()
        return jsonify({"ok": True, "status": status})

    rows = db.execute(
        """
        SELECT client_name, rating, message
        FROM reviews
        WHERE status = 'Approved'
        ORDER BY id DESC
        LIMIT 9
        """
    ).fetchall()
    return jsonify(
        [
            {
                "client_name": row["client_name"],
                "rating": row["rating"],
                "message": row["message"],
            }
            for row in rows
        ]
    )


@app.route("/api/contact-requests", methods=["POST"])
def api_contact_requests():
    payload = request.get_json(silent=True) or {}
    full_name = str(payload.get("full_name", "")).strip()
    phone = str(payload.get("phone", "")).strip()
    email = str(payload.get("email", "")).strip()
    service = str(payload.get("service", "")).strip()
    preferred_date = str(payload.get("preferred_date", "")).strip()
    location = str(payload.get("location", "")).strip()
    message = str(payload.get("message", "")).strip()

    if not full_name or not phone or not email or not service:
        return jsonify({"ok": False, "error": "Missing required fields."}), 400

    db = get_db()
    db.execute(
        """
        INSERT INTO contact_requests (
            full_name, phone, email, service, preferred_date, location, message, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'New', ?)
        """,
        (
            full_name,
            phone,
            email,
            service,
            preferred_date,
            location,
            message,
            datetime.now().isoformat(timespec="seconds"),
        ),
    )
    db.commit()
    return jsonify({"ok": True})


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
